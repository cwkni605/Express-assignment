var fs = require('fs');
fs.readdir('c:/', function(err, data) {
    console.log('data: ', data)
});
fs.readdir('c:/', phoneNumber);
console.log("This code is still last");
