var gulp = require('gulp');
gulp.task('default', function() {
    console.log('Hello from gulp!');
});