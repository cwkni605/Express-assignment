var myModule = require('./my-module.js');
console.log('Text from the external module: ', myModule.myText);