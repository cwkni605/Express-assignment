
exports.myText = 'Hello from my-module!';