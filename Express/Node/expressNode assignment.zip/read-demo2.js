var data = require('./data1.json');
console.log(data.name);